# Load up the stdlib
. ${SCRIPTPACK_STDLIB_ROOT}/main.sh

# Our own functions
. ${SCRIPTPACK_RUBY_ROOT}/install.sh
. ${SCRIPTPACK_RUBY_ROOT}/gem.sh
